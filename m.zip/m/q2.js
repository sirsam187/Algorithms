// Create Student Database, create collection student information and perform insert 
// operation. Write the following queries: 
//  Display student information who has secured more than 90%. 
//  Display student information who failed the examination 
//  Display student information who stays in Andheri 

const mongoose = require('mongoose');

// Connect to the MongoDB server
mongoose.connect('mongodb://127.0.0.1:27017/student2', )
.then(() => {
    console.log('Connected to MongoDB');
}).catch(err => {
    console.error('Failed to connect to MongoDB', err);
});

// Define the schema for a student
const studentSchema = new mongoose.Schema({
    name: String,
    percentage: Number,
    isFailed: Boolean,
    address: String
});

// Create a model for the student collection
const Student = mongoose.model('Student', studentSchema);

// Insert a new student
const insertStudent = async (name, percentage, isFailed, address) => {
    try {
        const student = new Student({
            name: name,
            percentage: percentage,
            isFailed: isFailed,
            address: address
        });
        await student.save();
        console.log('Student inserted successfully:', student);
    } catch (err) {
        console.error('Failed to insert student:', err);
    }
};

// Query: Display student information who has secured more than 90%
const displayTopStudents = async () => {
    try {
        const students = await Student.find({ percentage: { $gt: 90 } });
        console.log('Students who secured more than 90%:', students);
    } catch (err) {
        console.error('Failed to fetch top students:', err);
    }
};

// Query: Display student information who failed the examination
const displayFailedStudents = async () => {
    try {
        const students = await Student.find({ isFailed: true });
        console.log('Failed students:', students);
    } catch (err) {
        console.error('Failed to fetch failed students:', err);
    }
};

// Query: Display student information who stays in Andheri
const displayStudentsInAndheri = async () => {
    try {
        const students = await Student.find({ address: 'Andheri' });
        console.log('Students staying in Andheri:', students);
    } catch (err) {
        console.error('Failed to fetch students in Andheri:', err);
    }
};

// Example usage
insertStudent('John Doe', 95, false, 'Andheri');
insertStudent('Jane Smith', 75, true, 'Bandra');
insertStudent('Mike Johnson', 92, false, 'Andheri');

displayTopStudents();
displayFailedStudents();
displayStudentsInAndheri();
