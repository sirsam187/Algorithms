// Create Mongo dB Schema using mongoose module and find first data from data base and 
//  display on the browser 

const express = require('express');
const mongoose = require('mongoose');

// Create an Express app
const app = express();

// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/mydatabase2')
    .then(() => {
        console.log('Connected to MongoDB');
    }).catch(err => {
        console.error('Failed to connect to MongoDB', err);
    });

// Define the schema for a person
const personSchema = new mongoose.Schema({
    name: String,
    age: Number,
    email: String
});

// Create a model from the schema
const Person = mongoose.model('Person', personSchema);

const insertPerson = async (name, age, email) => {
    try {
        const student = new Person({
            name: name,
            age: age,
            email: email
        });
        await student.save();
        console.log('Student inserted successfully:', student);
    } catch (err) {
        console.error('Failed to insert student:', err);
    }
};

insertPerson('John Doe', 20, 'john@example.com');
insertPerson('Sachin Nawale', 19, 'sachin@example.com');

// Fetch the first person document from the database
app.get('/person',  async (req, res) => {
    try {
        const person =  await Person.findOne();
        res.json(person);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch person' });
    }
});

// Start the server
app.listen(4001, () => {
    console.log('Server is running on port 3000');
});

