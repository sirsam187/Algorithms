// Create Mongo dB Schema using mongoose module and insert data into database 

const mongoose = require('mongoose');

// Connect to the MongoDB server
mongoose.connect('mongodb://127.0.0.1:27017/student3').then(() => {
    console.log('Connected to MongoDB');
}).catch(err => {
    console.error('Failed to connect to MongoDB', err);
});

// Define the schema for a student
const studentSchema = new mongoose.Schema({
    name: String,
    age: Number,
    email: String
});

// Create a model from the schema
const Student = mongoose.model('Student', studentSchema);

// Insert a new student
const insertStudent = async (name, age, email) => {
    try {
        const student = new Student({
            name: name,
            age: age,
            email: email
        });
        await student.save();
        console.log('Student inserted successfully:', student);
    } catch (err) {
        console.error('Failed to insert student:', err);
    }
};

// Example usage
insertStudent('John Doe', 20, 'john@example.com');
