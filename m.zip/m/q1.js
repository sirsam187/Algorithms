// Create Student Database, create collection student information and perform insert, update, 
// remove operation.


const mongoose = require('mongoose');

// Connect to the MongoDB server
mongoose.connect('mongodb://127.0.0.1:27017/student1')
    .then(() => {
        console.log('Connected to MongoDB');
    })
    .catch(err => {
        console.error('Failed to connect to MongoDB', err);
    });

// Define the schema for a student
const studentSchema = new mongoose.Schema({
    name: String,
    age: Number,
    email: String
});

// Create a model for the student collection
const Student = mongoose.model('Student', studentSchema);

// Insert a new student
function insertStudent(name, age, email) {
    try {
        const student = new Student({
            name: name,
            age: age,
            email: email
        });
         student.save();
        console.log('Student inserted successfully:', student);
    } catch (err) {
        console.error('Failed to insert student:', err);
    }
};

// Update a student by email
const updateStudent = async (email, newAge) => {
    try {
        const student = Student.findOneAndUpdate({ email: email }, { age: newAge }, { new: true });
        console.log('Student updated successfully:', student);
    } catch (err) {
        console.error('Failed to update student:', err);
    }
};

// Remove a student by email
const removeStudent = async (email) => {
    try {
        const student = await Student.findOneAndRemove({ email: email });
        console.log('Student removed successfully:', student);
    } catch (err) {
        console.error('Failed to remove student:', err);
    }
};

// Example usage
insertStudent('John Doe', 20, 'john@example.com');
updateStudent('john@example.com', 21);
removeStudent('john@example.com');
